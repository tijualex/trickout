# Using-GAN-for-Fashion
This is a group project.



The main objective of this project is to perform Classification of dress and generation of new dress. Our project consists of 2 modules, the first being the classification of clothes based on pattern on the dress and the second is the generation of garments



DataSet :
https://s3.eu-central-1.amazonaws.com/fashion-gan/images.zip



Sneh Singh  ,
Vanama Yaswanth ,
Vidhi Mathur  .
